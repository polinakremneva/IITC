// data base
const computerBoard = [];
let playerBoard = [];
let roundCounter = 0;
win = false;
// flow
function generateComputerBoard() {
  const digits = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
  for (let i = 0; i < 4; i++) {
    const randomIndex = Math.floor(Math.random() * digits.length);
    computerBoard.push(digits[randomIndex]);
    digits.splice(randomIndex, 1);
  }
}

function appendToDisplay(value) {
  switch (roundCounter) {
    case 0:
      document.getElementById("display1").value += value;
      playerBoard.push(value);
      roundCounter++;
      break;
    case 1:
      if (playerBoard.includes(value)) {
        alert("You have already entered this number");
        roundCounter--;
      } else {
        document.getElementById("display2").value += value;
        playerBoard.push(value);
      }
      roundCounter++;
      break;
    case 2:
      if (playerBoard.includes(value)) {
        alert("You have already entered this number");
        roundCounter--;
      } else {
        document.getElementById("display3").value += value;
        playerBoard.push(value);
      }
      roundCounter++;
      break;
    case 3:
      if (playerBoard.includes(value)) {
        alert("You have already entered this number");
        roundCounter--;
      } else {
        document.getElementById("display4").value += value;
        playerBoard.push(value);
      }
      roundCounter++;
      break;
  }
}

function bullCheck() {
  let counter = 0;
  for (let i = 0; i < 4; i++) {
    if (computerBoard[i] === playerBoard[i]) {
      counter++;
    }
  }
  document.querySelector(".bull").innerText = "Bulls: " + counter;
}

function cowCheck() {
  let counter = 0;
  for (let i = 0; i < 4; i++) {
    if (
      playerBoard.includes(computerBoard[i]) &&
      computerBoard[i] != playerBoard[i]
    ) {
      counter++;
    }
  }
  document.querySelector(".cow").innerText = "Cows: " + counter;
}

function printEmptyLine() {
  playerBoard = [];
  document.getElementById("display1").value = "";
  document.getElementById("display2").value = "";
  document.getElementById("display3").value = "";
  document.getElementById("display4").value = "";
}

function checkBoard() {
  bullCheck();
  cowCheck();
  if (playerBoard.toString() === computerBoard.toString()) {
    win = true;
    alert("You win!");
  }
  if (roundCounter === 4) {
    printEmptyLine();
    roundCounter = 0;
  }

  addElement();
}

function addElement() {
  const newRow = document.createElement("div");
  newRow.id = "row";
  newRow.innerHTML = `
    <div id="left">
      <input class="window" id="display1" readonly />
      <input class="window" id="display2" readonly />
      <input class="window" id="display3" readonly />
      <input class="window" id="display4" readonly />
    </div>
    <div class="right">
      <button id="go" onclick="checkBoard()">Go</button>
    </div>
  `;
  document.getElementById("rows").appendChild(newRow);
}

generateComputerBoard();
